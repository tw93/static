# Notes

This is your personal notes space. Start creating your documents here!

**Quick Tips:**

- Press `⌘ + N` to create a new note
- Press `⌘ + Shift + N` to create a new folder
- Use folders to organize your notes by topics
